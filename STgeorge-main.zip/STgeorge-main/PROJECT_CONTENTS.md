# STgeorge - Church App

تطبيق كامل لكنيسة الشهيد العظيم مارجرجس

## 📦 محتويات المشروع

هذا المشروع يحتوي على:

### Screens (الشاشات)
```
src/screens/
├── HomeScreen.tsx                          # الشاشة الرئيسية
├── auth/
│   ├── AdminLoginScreen.tsx
│   ├── ServantLoginScreen.tsx
│   └── FatherLoginScreen.tsx
├── admin/
│   ├── AdminDashboardScreen.tsx
│   ├── ManageAnnouncementsScreen.tsx
│   ├── AddAnnouncementScreen.tsx
│   ├── EditAnnouncementScreen.tsx
│   ├── ManageServantsScreen.tsx
│   ├── ManageFathersScreen.tsx
│   └── ManageStudentsScreen.tsx
├── servant/
│   ├── ServantDashboardScreen.tsx
│   └── UploadPreparationScreen.tsx
├── father/
│   └── FatherDashboardScreen.tsx
└── sunday-school/
    ├── SundaySchoolScreen.tsx
    └── ClassDetailsScreen.tsx
```

### Store (إدارة الحالة)
```
src/store/
├── authStore.ts              # إدارة المصادقة
└── announcementStore.ts      # إدارة الإعلانات
```

### Navigation
```
src/navigation/
└── RootNavigator.tsx        # نظام التنقل الرئيسي
```

### Types
```
src/types/
└── index.ts                 # جميع أنواع TypeScript
```

### Config
```
src/config/
└── firebase.ts              # إعدادات Firebase
```

### Utils
```
src/utils/
└── notifications.ts         # وظائف الإشعارات
```

### Root Files
```
├── App.tsx                  # نقطة الدخول الرئيسية
├── app.json                 # إعدادات Expo
├── package.json             # المتطلبات
├── babel.config.js          # إعدادات Babel
└── .env.example             # مثال على متغيرات البيئة
```

### Documentation
```
├── README.md                # الملف التعريفي
├── DOCUMENTATION.md         # التوثيق الشامل
├── DEVELOPER.md             # دليل المطور
└── ROADMAP.md               # خريطة الطريق
```

## 🚀 للبدء السريع

```bash
git clone https://github.com/meinamekha-max/STgeorge.git
cd STgeorge
npm install
npm start
```

## 📱 المنصات المدعومة
- Android ✅
- iOS ✅
- Web ✅

## 🔐 حسابات الاختبار

### المدير
- Username: admin
- Password: admin123

### الخدام
- khadem1 / khadem1
- khadem2 / khadem2
- ... إلى khadem6

### الآباء
- father1 / father1
- father2 / father2
- father3 / father3

## 📄 الملفات المتاحة للتحميل

جميع ملفات المشروع موجودة في هذا المستودع:
- اضغط على "Code" → "Download ZIP"
- أو استخدم: `git clone`

## 📚 المراجع

- [DOCUMENTATION.md](./DOCUMENTATION.md) - توثيق شامل
- [DEVELOPER.md](./DEVELOPER.md) - دليل المطور
- [ROADMAP.md](./ROADMAP.md) - خريطة الطريق

---

**آخر تحديث: 2026-07-21**