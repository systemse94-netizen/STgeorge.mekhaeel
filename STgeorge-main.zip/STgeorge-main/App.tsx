import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import RootNavigator from './navigation/RootNavigator';
import { initializeUsers } from './store/authStore';

export default function App() {
  useEffect(() => {
    initializeUsers();
  }, []);

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#D4A574" />
      <RootNavigator />
    </>
  );
}