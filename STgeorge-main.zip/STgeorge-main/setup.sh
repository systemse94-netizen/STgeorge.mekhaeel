#!/bin/bash

# STgeorge Church App - Setup Script
# هذا السكريبت يساعد في إعداد المشروع بسهولة

echo "🚀 مرحباً بك في تطبيق كنيسة الشهيد العظيم مارجرجس"
echo ""

# التحقق من وجود Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js غير مثبت. يرجى تثبيت Node.js أولاً"
    exit 1
fi

echo "✅ Node.js موجود: $(node --version)"

# التحقق من وجود npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm غير مثبت"
    exit 1
fi

echo "✅ npm موجود: $(npm --version)"
echo ""

# تثبيت المكتبات
echo "📦 جاري تثبيت المكتبات..."
npm install

if [ $? -eq 0 ]; then
    echo "✅ تم تثبيت المكتبات بنجاح"
else
    echo "❌ فشل تثبيت المكتبات"
    exit 1
fi

echo ""
echo "🎉 تم إعداد المشروع بنجاح!"
echo ""
echo "الأوامر المتاحة:"
echo "  npm start     - لتشغيل التطبيق"
echo "  npm run ios   - لتشغيل على iOS"
echo "  npm run android - لتشغيل على Android"
echo "  npm run web   - لتشغيل على Web"
echo ""
echo "🔐 حسابات الاختبار:"
echo "  Admin: admin / admin123"
echo "  Fathers: father1/1, father2/2, father3/3"
echo "  Servants: khadem1/1, khadem2/2, ... khadem6/6"
echo ""
echo "📚 للمزيد من المعلومات:"
echo "  اقرأ DOCUMENTATION.md"
echo "  اقرأ DEVELOPER.md"
echo ""
