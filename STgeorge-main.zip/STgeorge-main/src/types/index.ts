// User Types
export enum UserRole {
  ADMIN = 'admin',
  FATHER = 'father',
  SERVANT = 'servant',
  STUDENT = 'student',
}

export interface User {
  id: string;
  username: string;
  password: string;
  role: UserRole;
  createdAt: number;
  updatedAt: number;
}

export interface Admin extends User {
  role: UserRole.ADMIN;
}

export interface Father extends User {
  role: UserRole.FATHER;
  fatherId: number; // 1, 2, or 3
}

export interface Servant extends User {
  role: UserRole.SERVANT;
  classId: string;
  className: string;
}

export interface Student {
  id: string;
  name: string;
  classId: string;
  className: string;
  photo?: string;
  createdAt: number;
  updatedAt: number;
}

// Class Types
export interface Class {
  id: string;
  name: string;
  grade: number; // 1-6
  totalStudents: number;
  totalServants: number;
  createdAt: number;
}

export const CLASSES = [
  { id: 'grade1', name: 'أولى ابتدائي', grade: 1 },
  { id: 'grade2', name: 'ثانية ابتدائي', grade: 2 },
  { id: 'grade3', name: 'ثالثة ابتدائي', grade: 3 },
  { id: 'grade4', name: 'رابعة ابتدائي', grade: 4 },
  { id: 'grade5', name: 'خامسة ابتدائي', grade: 5 },
  { id: 'grade6', name: 'سادسة ابتدائي', grade: 6 },
];

// Announcement Types
export interface Announcement {
  id: string;
  title: string;
  content: string;
  image?: string;
  isPinned: boolean;
  createdBy: string;
  createdAt: number;
  updatedAt: number;
}

// Preparation (كشكول الخدمة)
export interface PreparationImage {
  id: string;
  uri: string;
  timestamp: number;
}

export interface Preparation {
  id: string;
  servantId: string;
  servantName: string;
  classId: string;
  className: string;
  images: PreparationImage[];
  notes: string;
  uploadedAt: number;
  reviewed: boolean;
  reviewedBy?: string;
  reviewedAt?: number;
}

// Notifications
export interface NotificationData {
  id: string;
  title: string;
  body: string;
  data?: Record<string, any>;
  sentAt: number;
  read: boolean;
}

// Auth Context
export interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string, role: UserRole) => Promise<void>;
  logout: () => Promise<void>;
  register?: (user: User) => Promise<void>;
}

// Alerts
export interface ClassAlert {
  id: string;
  classId: string;
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high';
  createdAt: number;
}

// Meeting
export interface Meeting {
  id: string;
  classId: string;
  title: string;
  date: number; // timestamp
  time: string; // HH:mm format
  description?: string;
  createdAt: number;
}

// Class Notes
export interface ClassNote {
  id: string;
  classId: string;
  content: string;
  createdBy: string;
  createdAt: number;
  updatedAt: number;
}