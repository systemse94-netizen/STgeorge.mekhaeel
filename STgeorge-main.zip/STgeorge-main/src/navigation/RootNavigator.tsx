import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuthStore } from '../store/authStore';
import { UserRole } from '../types';

// Home & Auth Screens
import HomeScreen from '../screens/HomeScreen';
import AdminLoginScreen from '../screens/auth/AdminLoginScreen';
import ServantLoginScreen from '../screens/auth/ServantLoginScreen';
import FatherLoginScreen from '../screens/auth/FatherLoginScreen';

// Admin Screens
import AdminDashboardScreen from '../screens/admin/AdminDashboardScreen';
import ManageAnnouncementsScreen from '../screens/admin/ManageAnnouncementsScreen';
import AddAnnouncementScreen from '../screens/admin/AddAnnouncementScreen';
import EditAnnouncementScreen from '../screens/admin/EditAnnouncementScreen';

// Servant Screens
import ServantDashboardScreen from '../screens/servant/ServantDashboardScreen';
import UploadPreparationScreen from '../screens/servant/UploadPreparationScreen';

// Father Screens
import FatherDashboardScreen from '../screens/father/FatherDashboardScreen';

// Sunday School Screens
import SundaySchoolScreen from '../screens/sunday-school/SundaySchoolScreen';
import ClassDetailsScreen from '../screens/sunday-school/ClassDetailsScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function AnnouncementsStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="AnnouncementsList" component={ManageAnnouncementsScreen} />
      <Stack.Screen name="AddAnnouncement" component={AddAnnouncementScreen} />
      <Stack.Screen name="EditAnnouncement" component={EditAnnouncementScreen} />
    </Stack.Navigator>
  );
}

function AdminNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="AdminDashboard" component={AdminDashboardScreen} />
      <Stack.Screen name="ManageAnnouncements" component={AnnouncementsStack} />
    </Stack.Navigator>
  );
}

function ServantNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="ServantDashboard" component={ServantDashboardScreen} />
      <Stack.Screen name="UploadPreparation" component={UploadPreparationScreen} />
    </Stack.Navigator>
  );
}

function FatherNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="FatherDashboard" component={FatherDashboardScreen} />
    </Stack.Navigator>
  );
}

function SundaySchoolStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="SundaySchoolMain" component={SundaySchoolScreen} />
      <Stack.Screen name="ClassDetails" component={ClassDetailsScreen} />
      <Stack.Screen name="ServantLogin" component={ServantLoginScreen} />
    </Stack.Navigator>
  );
}

function AuthNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="AdminLogin" component={AdminLoginScreen} />
      <Stack.Screen name="ServantLogin" component={ServantLoginScreen} />
      <Stack.Screen name="FatherLogin" component={FatherLoginScreen} />
      <Stack.Screen name="SundaySchoolMain" component={SundaySchoolStack} />
    </Stack.Navigator>
  );
}

export default function RootNavigator() {
  const user = useAuthStore((state) => state.user);

  if (!user) {
    return (
      <NavigationContainer>
        <AuthNavigator />
      </NavigationContainer>
    );
  }

  if (user.role === UserRole.ADMIN) {
    return (
      <NavigationContainer>
        <AdminNavigator />
      </NavigationContainer>
    );
  }

  if (user.role === UserRole.SERVANT) {
    return (
      <NavigationContainer>
        <ServantNavigator />
      </NavigationContainer>
    );
  }

  if (user.role === UserRole.FATHER) {
    return (
      <NavigationContainer>
        <FatherNavigator />
      </NavigationContainer>
    );
  }

  return (
    <NavigationContainer>
      <AuthNavigator />
    </NavigationContainer>
  );
}