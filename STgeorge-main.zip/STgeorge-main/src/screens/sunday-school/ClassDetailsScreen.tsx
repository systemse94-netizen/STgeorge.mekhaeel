import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Student } from '../../types';

export default function ClassDetailsScreen({ navigation, route }: any) {
  const { classId, className } = route.params;
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    try {
      const data = await AsyncStorage.getItem('students');
      const allStudents = data ? JSON.parse(data) : [];
      const classStudents = allStudents.filter(
        (s: Student) => s.classId === classId
      );
      setStudents(classStudents);
    } catch (error) {
      console.error('Error loading students:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#D4A574" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{className}</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>
          التلاميذ ({students.length})
        </Text>

        {students.length === 0 ? (
          <Text style={styles.emptyText}>لا يوجد تلاميذ في هذا الفصل</Text>
        ) : (
          <FlatList
            data={students}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            numColumns={2}
            columnWrapperStyle={styles.row}
            renderItem={({ item }) => (
              <View style={styles.studentCard}>
                {item.photo ? (
                  <Image
                    source={{ uri: item.photo }}
                    style={styles.studentPhoto}
                  />
                ) : (
                  <View style={styles.studentPhotoPlaceholder}>
                    <Text style={styles.photoPlaceholderText}>📷</Text>
                  </View>
                )}
                <Text style={styles.studentName} numberOfLines={2}>
                  {item.name}
                </Text>
              </View>
            )}
          />
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  content: {
    flex: 1,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
    textAlign: 'right',
  },
  emptyText: {
    textAlign: 'center',
    color: '#999',
    fontSize: 14,
  },
  row: {
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  studentCard: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 10,
    overflow: 'hidden',
    alignItems: 'center',
  },
  studentPhoto: {
    width: '100%',
    height: 120,
  },
  studentPhotoPlaceholder: {
    width: '100%',
    height: 120,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoPlaceholderText: {
    fontSize: 32,
  },
  studentName: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
    paddingVertical: 10,
    paddingHorizontal: 8,
    textAlign: 'center',
  },
});