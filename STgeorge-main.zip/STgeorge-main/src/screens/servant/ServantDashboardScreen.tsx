import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Preparation } from '../../types';

export default function ServantDashboardScreen({ navigation, route }: any) {
  const { servantId, servantName, classId, className } = route.params || {};
  const [preparations, setPreparations] = useState<Preparation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPreparations();
  }, []);

  const loadPreparations = async () => {
    try {
      const data = await AsyncStorage.getItem('preparations');
      const allPreps = data ? JSON.parse(data) : [];
      const servantPreps = allPreps.filter((p: Preparation) => p.servantId === servantId);
      setPreparations(servantPreps);
    } catch (error) {
      console.error('Error loading preparations:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#D4A574" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>لوحة الخادم</Text>
        <Text style={styles.headerSubtitle}>{servantName}</Text>
      </View>

      <View style={styles.classInfo}>
        <Text style={styles.classInfoText}>{className}</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Upload Button */}
        <TouchableOpacity
          style={styles.uploadButton}
          onPress={() =>
            navigation.navigate('UploadPreparation', {
              servantId,
              servantName,
              classId,
              className,
            })
          }
        >
          <Text style={styles.uploadIcon}>📤</Text>
          <Text style={styles.uploadButtonText}>رفع تحضير جديد</Text>
        </TouchableOpacity>

        {/* Preparations List */}
        <Text style={styles.sectionTitle}>
          التحضيرات السابقة ({preparations.length})
        </Text>

        {preparations.length === 0 ? (
          <Text style={styles.emptyText}>لا توجد تحضيرات</Text>
        ) : (
          <FlatList
            data={preparations}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            renderItem={({ item }) => (
              <View style={styles.preparationCard}>
                <View style={styles.cardHeader}>
                  <View>
                    <Text style={styles.date}>
                      📅 {new Date(item.uploadedAt).toLocaleDateString('ar-EG')}
                    </Text>
                    <Text style={styles.time}>
                      🕐 {new Date(item.uploadedAt).toLocaleTimeString('ar-EG')}
                    </Text>
                  </View>
                  {item.reviewed && (
                    <View style={styles.reviewedBadge}>
                      <Text style={styles.reviewedBadgeText}>✓ تمت المراجعة</Text>
                    </View>
                  )}
                </View>

                <Text style={styles.imagesCount}>📷 {item.images.length} صورة</Text>

                {item.notes && (
                  <Text style={styles.notes} numberOfLines={2}>
                    ملاحظات: {item.notes}
                  </Text>
                )}

                {item.reviewedBy && (
                  <View style={styles.reviewInfo}>
                    <Text style={styles.reviewInfoText}>
                      ✓ تمت مراجعة التحضير بواسطة الأب الكاهن
                    </Text>
                  </View>
                )}
              </View>
            )}
          />
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#fff',
    textAlign: 'right',
    marginTop: 5,
  },
  classInfo: {
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  classInfoText: {
    textAlign: 'right',
    color: '#D4A574',
    fontWeight: 'bold',
    fontSize: 16,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  uploadButton: {
    backgroundColor: '#27ae60',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    marginBottom: 20,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  uploadIcon: {
    fontSize: 20,
    marginRight: 10,
  },
  uploadButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
    textAlign: 'right',
  },
  emptyText: {
    textAlign: 'center',
    color: '#999',
    fontSize: 14,
  },
  preparationCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#D4A574',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  date: {
    fontSize: 13,
    color: '#333',
    fontWeight: '600',
    marginBottom: 3,
  },
  time: {
    fontSize: 12,
    color: '#666',
  },
  reviewedBadge: {
    backgroundColor: '#e8f5e9',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#27ae60',
  },
  reviewedBadgeText: {
    color: '#27ae60',
    fontWeight: 'bold',
    fontSize: 12,
  },
  imagesCount: {
    fontSize: 13,
    color: '#666',
    marginBottom: 8,
  },
  notes: {
    fontSize: 12,
    color: '#999',
    marginBottom: 8,
    fontStyle: 'italic',
  },
  reviewInfo: {
    backgroundColor: '#e8f5e9',
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 10,
    marginTop: 8,
  },
  reviewInfoText: {
    color: '#27ae60',
    fontSize: 12,
    fontWeight: '600',
  },
});