import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export default function SundaySchoolScreen({ navigation }: any) {
  const [selectedTab, setSelectedTab] = useState<'students' | 'servants'>('students');

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>خدمة مدارس الأحد</Text>
      </View>

      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'students' && styles.activeTab]}
          onPress={() => setSelectedTab('students')}
        >
          <Text style={[styles.tabText, selectedTab === 'students' && styles.activeTabText]}>
            التلاميذ
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, selectedTab === 'servants' && styles.activeTab]}
          onPress={() => setSelectedTab('servants')}
        >
          <Text style={[styles.tabText, selectedTab === 'servants' && styles.activeTabText]}>
            الخدام
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {selectedTab === 'students' ? (
          <View>
            <Text style={styles.sectionTitle}>اختر الفصل</Text>
            {[
              { id: 'grade1', name: 'أولى ابتدائي' },
              { id: 'grade2', name: 'ثانية ابتدائي' },
              { id: 'grade3', name: 'ثالثة ابتدائي' },
              { id: 'grade4', name: 'رابعة ابتدائي' },
              { id: 'grade5', name: 'خامسة ابتدائي' },
              { id: 'grade6', name: 'سادسة ابتدائي' },
            ].map((grade) => (
              <TouchableOpacity
                key={grade.id}
                style={styles.classCard}
                onPress={() =>
                  navigation.navigate('ClassDetails', { classId: grade.id, className: grade.name })
                }
              >
                <Text style={styles.className}>{grade.name}</Text>
                <Text style={styles.arrow}>›</Text>
              </TouchableOpacity>
            ))}
          </View>
        ) : (
          <View>
            <TouchableOpacity
              style={styles.servantLoginButton}
              onPress={() => navigation.navigate('ServantLogin')}
            >
              <Text style={styles.servantLoginText}>تسجيل دخول الخادم</Text>
            </TouchableOpacity>
            <Text style={styles.loginHint}>الخدام يرجى تسجيل الدخول أولاً</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: '#D4A574',
  },
  tabText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  activeTabText: {
    color: '#D4A574',
  },
  content: {
    flex: 1,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
    textAlign: 'right',
  },
  classCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 15,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#D4A574',
  },
  className: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    flex: 1,
    textAlign: 'right',
  },
  arrow: {
    fontSize: 20,
    color: '#D4A574',
  },
  servantLoginButton: {
    backgroundColor: '#D4A574',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    marginVertical: 20,
  },
  servantLoginText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  loginHint: {
    textAlign: 'center',
    color: '#666',
    fontSize: 14,
  },
});