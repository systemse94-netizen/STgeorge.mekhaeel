import { create } from 'zustand';
import { Announcement } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AnnouncementStore {
  announcements: Announcement[];
  loading: boolean;
  fetchAnnouncements: () => Promise<void>;
  addAnnouncement: (announcement: Announcement) => Promise<void>;
  updateAnnouncement: (id: string, updates: Partial<Announcement>) => Promise<void>;
  deleteAnnouncement: (id: string) => Promise<void>;
  setPinned: (id: string, isPinned: boolean) => Promise<void>;
}

export const useAnnouncementStore = create<AnnouncementStore>((set, get) => ({
  announcements: [],
  loading: false,

  fetchAnnouncements: async () => {
    set({ loading: true });
    try {
      const data = await AsyncStorage.getItem('announcements');
      const announcements = data ? JSON.parse(data) : [];
      set({ announcements: announcements.sort((a: Announcement, b: Announcement) => b.createdAt - a.createdAt) });
    } catch (error) {
      console.error('Error fetching announcements:', error);
    } finally {
      set({ loading: false });
    }
  },

  addAnnouncement: async (announcement: Announcement) => {
    try {
      const current = get().announcements;
      const updated = [announcement, ...current];
      await AsyncStorage.setItem('announcements', JSON.stringify(updated));
      set({ announcements: updated });
    } catch (error) {
      console.error('Error adding announcement:', error);
      throw error;
    }
  },

  updateAnnouncement: async (id: string, updates: Partial<Announcement>) => {
    try {
      const current = get().announcements;
      const updated = current.map((ann) =>
        ann.id === id ? { ...ann, ...updates, updatedAt: Date.now() } : ann
      );
      await AsyncStorage.setItem('announcements', JSON.stringify(updated));
      set({ announcements: updated });
    } catch (error) {
      console.error('Error updating announcement:', error);
      throw error;
    }
  },

  deleteAnnouncement: async (id: string) => {
    try {
      const current = get().announcements;
      const updated = current.filter((ann) => ann.id !== id);
      await AsyncStorage.setItem('announcements', JSON.stringify(updated));
      set({ announcements: updated });
    } catch (error) {
      console.error('Error deleting announcement:', error);
      throw error;
    }
  },

  setPinned: async (id: string, isPinned: boolean) => {
    try {
      const current = get().announcements;
      const updated = current.map((ann) =>
        ann.id === id ? { ...ann, isPinned, updatedAt: Date.now() } : ann
      );
      await AsyncStorage.setItem('announcements', JSON.stringify(updated));
      set({ announcements: updated });
    } catch (error) {
      console.error('Error pinning announcement:', error);
      throw error;
    }
  },
}));