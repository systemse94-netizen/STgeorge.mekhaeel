import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Alert,
  ScrollView,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Preparation, PreparationImage } from '../../types';
import uuid from 'react-native-uuid';

export default function UploadPreparationScreen({ navigation, route }: any) {
  const { servantId, servantName, classId, className } = route.params;
  const [images, setImages] = useState<PreparationImage[]>([]);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultiple: true,
        quality: 0.8,
      });

      if (!result.canceled) {
        const newImages = result.assets.map((asset) => ({
          id: uuid.v4() as string,
          uri: asset.uri,
          timestamp: Date.now(),
        }));
        setImages([...images, ...newImages]);
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل تحميل الصورة');
    }
  };

  const takePhoto = async () => {
    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled) {
        const newImage: PreparationImage = {
          id: uuid.v4() as string,
          uri: result.assets[0].uri,
          timestamp: Date.now(),
        };
        setImages([...images, newImage]);
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل التقاط الصورة');
    }
  };

  const removeImage = (id: string) => {
    setImages(images.filter((img) => img.id !== id));
  };

  const handleSubmit = async () => {
    if (images.length === 0) {
      Alert.alert('خطأ', 'يرجى اختيار صورة واحدة على الأقل');
      return;
    }

    setLoading(true);
    try {
      const preparation: Preparation = {
        id: uuid.v4() as string,
        servantId,
        servantName,
        classId,
        className,
        images,
        notes,
        uploadedAt: Date.now(),
        reviewed: false,
      };

      const existing = await AsyncStorage.getItem('preparations');
      const preparations = existing ? JSON.parse(existing) : [];
      preparations.push(preparation);
      await AsyncStorage.setItem('preparations', JSON.stringify(preparations));

      Alert.alert('نجاح', 'تم حفظ التحضير بنجاح');
      navigation.goBack();
    } catch (error) {
      Alert.alert('خطأ', 'فشل حفظ التحضير');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>رفع التحضير</Text>
        <Text style={styles.headerSubtitle}>{className}</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Image Actions */}
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.actionButton} onPress={takePhoto}>
            <Text style={styles.buttonIcon}>📷</Text>
            <Text style={styles.buttonLabel}>التقط صورة</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton} onPress={pickImage}>
            <Text style={styles.buttonIcon}>🖼️</Text>
            <Text style={styles.buttonLabel}>اختر صورة</Text>
          </TouchableOpacity>
        </View>

        {/* Images Preview */}
        {images.length > 0 && (
          <View style={styles.imagesContainer}>
            <Text style={styles.imagesTitle}>الصور المرفوعة ({images.length})</Text>
            {images.map((image) => (
              <View key={image.id} style={styles.imageItem}>
                <Text style={styles.imageLabel}>
                  صورة - {new Date(image.timestamp).toLocaleTimeString('ar-EG')}
                </Text>
                <TouchableOpacity
                  style={styles.removeButton}
                  onPress={() => removeImage(image.id)}
                >
                  <Text style={styles.removeButtonText}>✕</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}

        {/* Notes */}
        <View style={styles.notesContainer}>
          <Text style={styles.notesLabel}>الملاحظات</Text>
          <TextInput
            style={styles.notesInput}
            placeholder="أضف ملاحظات عن التحضير (اختياري)"
            placeholderTextColor="#999"
            multiline
            numberOfLines={4}
            value={notes}
            onChangeText={setNotes}
            textAlignVertical="top"
          />
        </View>
      </ScrollView>

      {/* Submit Button */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.submitButton, loading && styles.buttonDisabled]}
          onPress={handleSubmit}
          disabled={loading}
        >
          <Text style={styles.submitButtonText}>
            {loading ? 'جاري الحفظ...' : 'حفظ التحضير'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#fff',
    textAlign: 'right',
    marginTop: 5,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#D4A574',
  },
  buttonIcon: {
    fontSize: 24,
    marginBottom: 5,
  },
  buttonLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
  },
  imagesContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
  },
  imagesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  imageItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#D4A574',
  },
  imageLabel: {
    fontSize: 13,
    color: '#666',
    flex: 1,
    textAlign: 'right',
  },
  removeButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#e74c3c',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  removeButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  notesContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
  },
  notesLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  notesInput: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
  },
  footer: {
    padding: 15,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  submitButton: {
    backgroundColor: '#27ae60',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});