import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

export default function HomeScreen({ navigation }: any) {
  const menuItems = [
    {
      id: 'announcements',
      icon: '📢',
      title: 'الإعلانات',
      description: 'آخر الأخبار والإعلانات',
      color: '#3498db',
      action: () => {},
    },
    {
      id: 'sunday-school',
      icon: '📚',
      title: 'مدارس الأحد',
      description: 'إدارة الفصول والتلاميذ',
      color: '#27ae60',
      action: () => navigation.navigate('SundaySchoolMain'),
    },
    {
      id: 'admin',
      icon: '👨‍💼',
      title: 'لوحة الإدارة',
      description: 'للمدير فقط',
      color: '#e74c3c',
      action: () => navigation.navigate('AdminLogin'),
    },
    {
      id: 'father',
      icon: '⛪',
      title: 'الأب الكاهن',
      description: 'مراجعة التحضيرات',
      color: '#9b59b6',
      action: () => navigation.navigate('FatherLogin'),
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>كنيسة الشهيد العظيم مارجرجس</Text>
        <Text style={styles.headerSubtitle}>القاهرة - مصر</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.welcomeText}>مرحباً بك في التطبيق</Text>

        {menuItems.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[styles.menuCard, { borderLeftColor: item.color }]}
            onPress={item.action}
          >
            <Text style={styles.menuIcon}>{item.icon}</Text>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>{item.title}</Text>
              <Text style={styles.menuDescription}>{item.description}</Text>
            </View>
            <Text style={styles.arrow}>›</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 30,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#fff',
    textAlign: 'center',
    marginTop: 5,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  welcomeText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textAlign: 'right',
  },
  menuCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingVertical: 15,
    paddingHorizontal: 15,
    marginBottom: 10,
    borderLeftWidth: 5,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  menuIcon: {
    fontSize: 32,
    marginRight: 15,
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'right',
  },
  menuDescription: {
    fontSize: 12,
    color: '#999',
    marginTop: 3,
    textAlign: 'right',
  },
  arrow: {
    fontSize: 24,
    color: '#D4A574',
  },
});