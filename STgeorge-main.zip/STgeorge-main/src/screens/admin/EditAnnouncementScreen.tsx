import React, { useState } from 'react';
import {
  View,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { useAnnouncementStore } from '../../store/announcementStore';
import { Announcement } from '../../types';
import uuid from 'react-native-uuid';

export default function EditAnnouncementScreen({ navigation, route }: any) {
  const { announcement } = route.params;
  const [title, setTitle] = useState(announcement.title);
  const [content, setContent] = useState(announcement.content);
  const [loading, setLoading] = useState(false);
  const { updateAnnouncement } = useAnnouncementStore();

  const handleUpdate = async () => {
    if (!title.trim() || !content.trim()) {
      Alert.alert('خطأ', 'يرجى ملء جميع الحقول');
      return;
    }

    setLoading(true);
    try {
      await updateAnnouncement(announcement.id, { title, content });
      Alert.alert('نجاح', 'تم تحديث الإعلان بنجاح');
      navigation.goBack();
    } catch (error: any) {
      Alert.alert('خطأ', error.message || 'حدث خطأ أثناء تحديث الإعلان');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.container}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>تعديل الإعلان</Text>
        </View>

        <View style={styles.form}>
          <Text style={styles.label}>عنوان الإعلان</Text>
          <TextInput
            style={styles.input}
            placeholder="أدخل عنوان الإعلان"
            value={title}
            onChangeText={setTitle}
            placeholderTextColor="#999"
            editable={!loading}
          />

          <Text style={styles.label}>محتوى الإعلان</Text>
          <TextInput
            style={[styles.input, styles.largeInput]}
            placeholder="أدخل محتوى الإعلان"
            value={content}
            onChangeText={setContent}
            placeholderTextColor="#999"
            multiline
            numberOfLines={6}
            textAlignVertical="top"
            editable={!loading}
          />
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleUpdate}
          disabled={loading}
        >
          <Text style={styles.buttonText}>{loading ? 'جاري التحديث...' : 'تحديث الإعلان'}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, styles.cancelButton]}
          onPress={() => navigation.goBack()}
          disabled={loading}
        >
          <Text style={styles.buttonText}>إلغاء</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  form: {
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
    textAlign: 'right',
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginBottom: 20,
    fontSize: 14,
    textAlign: 'right',
  },
  largeInput: {
    height: 120,
  },
  footer: {
    flexDirection: 'row',
    gap: 10,
    padding: 15,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  button: {
    flex: 1,
    backgroundColor: '#3498db',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#95a5a6',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});