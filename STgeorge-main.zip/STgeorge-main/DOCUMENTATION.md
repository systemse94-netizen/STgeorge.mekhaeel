# 📱 تطبيق كنيسة الشهيد العظيم مارجرجس

**تطبيق شامل لإدارة خدمة مدارس الأحد والإعلانات والتحضيرات**

## 🎯 الميزات الرئيسية

### 1. 📢 نظام الإعلانات (Announcements System)
- ✅ إضافة إعلانات جديدة
- ✅ تعديل الإعلانات الموجودة
- ✅ حذف الإعلانات
- ✅ تثبيت الإعلانات المهمة
- ✅ عرض الإعلانات الأحدث أولاً
- ✅ إشعارات فورية عند إضافة إعلان جديد

### 2. 👦 خدمة مدارس الأحد (Sunday School)

#### قسم التلاميذ
- عرض 6 فصول (من أولى إلى سادسة ابتدائي)
- عرض التلاميذ والصور والخدام
- عرض مقروء فقط (بدون تعديل)

#### قسم الخدام
- تسجيل دخول آمن (6 حسابات)
- إدارة بيانات الفصل الخاص به فقط
- إضافة/تعديل/حذف التلاميذ
- رفع صور التلاميذ
- إضافة/تعديل/حذف الخدام
- إضافة ملاحظات ومواعيد

### 3. 📝 كشكول الخدمة (Service Notebook)

#### حساب الخادم
- التقاط صور التحضير بالكاميرا
- رفع صور متعددة
- كتابة ملاحظات
- حفظ التحضير مع التاريخ والوقت
- عرض سجل التحضيرات السابقة
- عرض حالة المراجعة

#### حساب الأب الكاهن
- عرض جميع التحضيرات
- متابعة من رفع ومن لم يرفع
- مراجعة التحضيرات
- وضع علامة "تمت المراجعة"
- لوحة إحصائيات شاملة
- البحث والترتيب

### 4. 🔐 نظام الحسابات

#### الحسابات الافتراضية

**المدير (Admin)**
```
Username: admin
Password: admin123
```

**الآباء الكهنة (Fathers)**
```
father1 / father1
father2 / father2
father3 / father3
```

**الخدام (Servants)**
```
khadem1 / khadem1  → أولى ابتدائي
khadem2 / khadem2  → ثانية ابتدائي
khadem3 / khadem3  → ثالثة ابتدائي
khadem4 / khadem4  → رابعة ابتدائي
khadem5 / khadem5  → خامسة ابتدائي
khadem6 / khadem6  → سادسة ابتدائي
```

## 📁 هيكل المشروع

```
STgeorge/
├── src/
│   ├── config/
│   │   └── firebase.ts              # إعدادات Firebase
│   ├── navigation/
│   │   └── RootNavigator.tsx       # نظام التنقل الرئيسي
│   ├── screens/
│   │   ├── HomeScreen.tsx           # الشاشة الرئيسية
│   │   ├── auth/
│   │   │   ├── AdminLoginScreen.tsx
│   │   │   ├── ServantLoginScreen.tsx
│   │   │   └── FatherLoginScreen.tsx
│   │   ├── admin/
│   │   │   ├── AdminDashboardScreen.tsx
│   │   │   ├── ManageAnnouncementsScreen.tsx
│   │   │   ├── AddAnnouncementScreen.tsx
│   │   │   ├── EditAnnouncementScreen.tsx
│   │   │   ├── ManageServantsScreen.tsx
│   │   │   ├── ManageFathersScreen.tsx
│   │   │   └── ManageStudentsScreen.tsx
│   │   ├── servant/
│   │   │   ├── ServantDashboardScreen.tsx
│   │   │   └── UploadPreparationScreen.tsx
│   │   ├── father/
│   │   │   └── FatherDashboardScreen.tsx
│   │   └── sunday-school/
│   │       ├── SundaySchoolScreen.tsx
│   │       └── ClassDetailsScreen.tsx
│   ├── store/
│   │   ├── authStore.ts            # إدارة المصادقة
│   │   └── announcementStore.ts    # إدارة الإعلانات
│   ├── types/
│   │   └── index.ts                # أنواع TypeScript
│   └── utils/
│       └── notifications.ts        # وظائف الإشعارات
├── App.tsx                          # نقطة الدخول الرئيسية
├── app.json                         # إعدادات Expo
├── package.json
└── babel.config.js
```

## 🚀 التثبيت والتشغيل

### المتطلبات
- Node.js 16+
- npm أو yarn
- Expo CLI

### خطوات التثبيت

```bash
# 1. استنساخ المشروع
git clone https://github.com/meinamekha-max/STgeorge.git
cd STgeorge

# 2. تثبيت المكتبات
npm install
# أو
yarn install

# 3. تشغيل التطبيق
npm start
# أو
expo start

# 4. تشغيل على الهاتف
# iOS
npm run ios

# Android
npm run android

# Web
npm run web
```

## 🔧 إعدادات Firebase

### إعداد مشروع Firebase

1. توجه إلى [Firebase Console](https://console.firebase.google.com/)
2. أنشئ مشروع جديد
3. أضف تطبيق React Native
4. انسخ بيانات الإعدادات

### تكوين الملف `.env`

أنشئ ملف `.env` في جذر المشروع:

```env
EXPO_PUBLIC_FIREBASE_API_KEY=your_api_key
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your_auth_domain
EXPO_PUBLIC_FIREBASE_DB_URL=your_database_url
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
EXPO_PUBLIC_FIREBASE_STORAGE=your_storage_bucket
EXPO_PUBLIC_FIREBASE_MESSAGING_ID=your_messaging_id
EXPO_PUBLIC_FIREBASE_APP_ID=your_app_id
```

## 📊 قاعدة البيانات

### البيانات المخزنة محلياً (AsyncStorage)

```typescript
// Users
{
  id: string
  username: string
  password: string
  role: 'admin' | 'father' | 'servant' | 'student'
  createdAt: number
}

// Announcements
{
  id: string
  title: string
  content: string
  image?: string
  isPinned: boolean
  createdBy: string
  createdAt: number
  updatedAt: number
}

// Preparations
{
  id: string
  servantId: string
  servantName: string
  classId: string
  className: string
  images: {
    id: string
    uri: string
    timestamp: number
  }[]
  notes: string
  uploadedAt: number
  reviewed: boolean
  reviewedBy?: string
  reviewedAt?: number
}

// Students
{
  id: string
  name: string
  classId: string
  className: string
  photo?: string
  createdAt: number
}
```

## 👥 الأدوار والصلاحيات

### 🛡️ المدير (Admin)
- إدارة جميع الإعلانات
- إنشاء حسابات الخدام والآباء
- تعديل أو حذف أي حساب
- إدارة جميع البيانات
- الوصول الكامل للنظام

### ⛪ الأب الكاهن (Father)
- عرض جميع الفصول والخدام
- مشاهدة جميع التحضيرات
- مراجعة التحضيرات
- وضع علامة "تمت المراجعة"
- متابعة الإحصائيات
- البحث والترتيب

### 👨‍💼 الخادم (Servant)
- الدخول إلى الفصل الخاص به فقط
- رفع التحضيرات
- إدارة البيانات داخل فصله
- إضافة/تعديل التلاميذ والخدام
- إضافة الملاحظات والمواعيد
- عرض حالة المراجعة

### 👤 التلميذ (Student)
- عرض بيانات الفصل فقط
- مشاهدة الزملاء والخدام
- بدون صلاحيات تعديل

## 🎨 التصميم والألوان

```typescript
// الألوان الأساسية
Primary: #D4A574     // البني الذهبي
Success: #27ae60     // الأخضر
Danger: #e74c3c      // الأحمر
Info: #3498db        // الأزرق
Warning: #f39c12     // البرتقالي
Purple: #9b59b6      // البنفسجي
Background: #f5f5f5  // الرمادي الفاتح
```

## 🔄 سير العمل

### 1️⃣ تدفق الإعلانات
```
Admin Login → Admin Dashboard → Manage Announcements
         ↓
    Create/Edit/Delete
         ↓
   Save to AsyncStorage
         ↓
  Send Push Notifications
         ↓
   Display in Home Screen
```

### 2️⃣ تدفق مدارس الأحد
```
Home Screen → Sunday School
    ↓
    ├─ Students View → Select Class → View Students
    │
    └─ Servants View → Login → Servant Dashboard
                ↓
           Manage Class Data
```

### 3️⃣ تدفق التحضيرات
```
Servant Dashboard → Upload Preparation
         ↓
    Add Photos (Camera/Gallery)
    Add Notes
    Submit
         ↓
    Saved to AsyncStorage
         ↓
Father Login → Father Dashboard
    View Preparations
    Review & Mark as Reviewed
```

## 🧪 الاختبار

### خطوات اختبار النظام

1. **اختبار الإعلانات**
   - سجل دخول كمدير
   - أضف إعلان جديد
   - تحقق من ظهوره في الشاشة الرئيسية
   - جرب التثبيت والتعديل والحذف

2. **اختبار مدارس الأحد**
   - اختبر عرض التلاميذ بدون تسجيل
   - سجل دخول كخادم
   - أضف تلميذ جديد
   - تحقق من عدم القدرة على الوصول لفصول أخرى

3. **اختبار التحضيرات**
   - سجل دخول كخادم
   - رفع تحضير مع صور وملاحظات
   - سجل دخول كأب كاهن
   - مراجعة التحضيرات والتحقق من الإحصائيات

## 📚 مكتبات مهمة

```json
{
  "react-navigation": "للتنقل بين الشاشات",
  "zustand": "لإدارة الحالة العالمية",
  "react-native-async-storage": "للتخزين المحلي",
  "expo-image-picker": "لاختيار الصور",
  "expo-camera": "للتقاط الصور",
  "expo-notifications": "للإشعارات",
  "firebase": "لقاعدة البيانات السحابية"
}
```

## 🐛 استكشاف الأخطاء

### المشكلة: لا تظهر الإعلانات
**الحل:**
- تحقق من وجود بيانات في AsyncStorage
- تحقق من استدعاء `fetchAnnouncements()`
- قم بتنظيف الكاش: `expo send -c`

### المشكلة: خطأ في رفع الصور
**الحل:**
- تحقق من صلاحيات الكاميرا والمعرض
- تأكد من وجود مساحة تخزين كافية
- جرب إعادة تشغيل التطبيق

### المشكلة: عدم ظهور الإشعارات
**الحل:**
- تحقق من تفعيل الإشعارات في إعدادات الجهاز
- تحقق من استدعاء `registerForPushNotifications()`
- جرب إرسال إشعار اختبار

## 📞 الدعم والتطوير المستقبلي

### ميزات مخطط إضافتها
- [ ] Sync مع Firebase Realtime Database
- [ ] دعم اللغة الإنجليزية
- [ ] ميزة البحث المتقدم
- [ ] تقارير شاملة
- [ ] دعم الحضور والغياب
- [ ] نظام تقييم الخدام
- [ ] تحديثات تلقائية

## 📄 الترخيص

هذا المشروع خاص بكنيسة الشهيد العظيم مارجرجس

## 👨‍💻 المطور

**Michael Yasser Yackoub**
- GitHub: [@meinamekha-max](https://github.com/meinamekha-max)
- البريد: meinamekha@gmail.com

---

**تم التطوير بـ ❤️ لخدمة الكنيسة**

*آخر تحديث: 2026-07-21*