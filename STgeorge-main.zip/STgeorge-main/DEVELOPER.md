# دليل المطور - Church App

## 📖 مقدمة

هذا الدليل يوضح كيفية الإضافة والتعديل والتطوير على التطبيق.

## 🏗️ إضافة ميزة جديدة

### خطوة 1: إنشاء نوع جديد

أضف النوع في `src/types/index.ts`:

```typescript
export interface MyNewFeature {
  id: string;
  title: string;
  createdAt: number;
}
```

### خطوة 2: إنشاء Store (Zustand)

أنشئ ملف `src/store/myFeatureStore.ts`:

```typescript
import { create } from 'zustand';
import { MyNewFeature } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface MyFeatureStore {
  items: MyNewFeature[];
  loading: boolean;
  fetchItems: () => Promise<void>;
  addItem: (item: MyNewFeature) => Promise<void>;
  updateItem: (id: string, updates: Partial<MyNewFeature>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
}

export const useMyFeatureStore = create<MyFeatureStore>((set, get) => ({
  items: [],
  loading: false,

  fetchItems: async () => {
    set({ loading: true });
    try {
      const data = await AsyncStorage.getItem('myFeature');
      set({ items: data ? JSON.parse(data) : [] });
    } catch (error) {
      console.error('Error fetching items:', error);
    } finally {
      set({ loading: false });
    }
  },

  addItem: async (item) => {
    try {
      const current = get().items;
      const updated = [item, ...current];
      await AsyncStorage.setItem('myFeature', JSON.stringify(updated));
      set({ items: updated });
    } catch (error) {
      console.error('Error adding item:', error);
      throw error;
    }
  },

  updateItem: async (id, updates) => {
    try {
      const current = get().items;
      const updated = current.map((item) =>
        item.id === id ? { ...item, ...updates } : item
      );
      await AsyncStorage.setItem('myFeature', JSON.stringify(updated));
      set({ items: updated });
    } catch (error) {
      console.error('Error updating item:', error);
      throw error;
    }
  },

  deleteItem: async (id) => {
    try {
      const current = get().items;
      const updated = current.filter((item) => item.id !== id);
      await AsyncStorage.setItem('myFeature', JSON.stringify(updated));
      set({ items: updated });
    } catch (error) {
      console.error('Error deleting item:', error);
      throw error;
    }
  },
}));
```

### خطوة 3: إنشاء الشاشات

أنشئ `src/screens/myfeature/MyFeatureListScreen.tsx`:

```typescript
import React, { useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, FlatList } from 'react-native';
import { useMyFeatureStore } from '../../store/myFeatureStore';

export default function MyFeatureListScreen() {
  const { items, loading, fetchItems } = useMyFeatureStore();

  useEffect(() => {
    fetchItems();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الميزة الجديدة</Text>
      </View>

      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.title}>{item.title}</Text>
          </View>
        )}
        contentContainerStyle={styles.list}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  list: {
    padding: 15,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});
```

### خطوة 4: إضافة في Navigation

عدّل `src/navigation/RootNavigator.tsx`:

```typescript
import MyFeatureListScreen from '../screens/myfeature/MyFeatureListScreen';

// في الـ Stack Navigator
<Stack.Screen name="MyFeature" component={MyFeatureListScreen} />
```

## 🎨 معايير التصميم

### الألوان
- Primary: `#D4A574` - للرؤوس والزر الرئيسي
- Success: `#27ae60` - للعمليات الناجحة
- Danger: `#e74c3c` - للحذف والأخطاء
- Info: `#3498db` - للمعلومات
- Background: `#f5f5f5` - خلفية الشاشة

### الخطوط
- العنوان: 24px, Bold
- العنوان الفرعي: 16px, Bold
- النص: 14px, Normal
- الملاحظات: 12px, Normal

### الحشو (Padding)
```typescript
{
  xs: 5,
  sm: 10,
  md: 15,
  lg: 20,
  xl: 25,
}
```

## 🔌 الاتصال مع Firebase

### قراءة البيانات

```typescript
import { db } from '../config/firebase';
import { ref, onValue } from 'firebase/database';

const fetchData = () => {
  const dataRef = ref(db, 'announcements');
  onValue(dataRef, (snapshot) => {
    const data = snapshot.val();
    console.log(data);
  });
};
```

### كتابة البيانات

```typescript
import { set } from 'firebase/database';

const saveData = async (data) => {
  try {
    await set(ref(db, 'announcements/' + id), data);
  } catch (error) {
    console.error('Error saving data:', error);
  }
};
```

## 📤 إضافة الإشعارات

```typescript
import { sendPushNotification } from '../utils/notifications';

const notifyUsers = async () => {
  await sendPushNotification(
    'عنوان الإشعار',
    'محتوى الإشعار',
    { type: 'announcement', id: '123' }
  );
};
```

## 🧹 معايير الكود

### التسمية
- Components: PascalCase (MyComponent.tsx)
- Functions: camelCase (myFunction)
- Constants: UPPER_CASE (MY_CONSTANT)
- Types: PascalCase (MyType)

### الاستيراد
```typescript
// الترتيب
import React from 'react';
import { View, Text } from 'react-native';
import { useStore } from '../store';
import { MyType } from '../types';
import MyComponent from '../components/MyComponent';
```

## 🧪 الاختبار

### اختبار العمليات
```typescript
describe('MyFeature', () => {
  test('should add item', async () => {
    const store = useMyFeatureStore();
    const item = { id: '1', title: 'Test', createdAt: Date.now() };
    await store.addItem(item);
    expect(store.items).toContain(item);
  });
});
```

## 🚢 النشر

### نشر على Google Play
```bash
eas build --platform android --auto-submit
```

### نشر على App Store
```bash
eas build --platform ios --auto-submit
```

## 📝 ملاحظات مهمة

1. **دائماً استخدم try-catch** عند التعامل مع AsyncStorage
2. **تحقق من الصلاحيات** قبل استخدام الكاميرا أو المعرض
3. **استخدم تحديثات الحالة** بشكل صحيح
4. **اختبر على أجهزة فعلية** وليس فقط المحاكي
5. **وثق الكود** بشكل واضح

## 🆘 الحصول على المساعدة

- GitHub Issues: قم بإنشاء Issue جديد
- البريد الإلكتروني: meinamekha@gmail.com
- Discussions: استخدم GitHub Discussions

---

**آخر تحديث: 2026-07-21**