import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Preparation } from '../../types';

export default function FatherDashboardScreen({ navigation }: any) {
  const [preparations, setPreparations] = useState<Preparation[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    uploadedToday: 0,
    notUploaded: 0,
    reviewed: 0,
    notReviewed: 0,
  });

  useEffect(() => {
    loadPreparations();
  }, []);

  const loadPreparations = async () => {
    try {
      const data = await AsyncStorage.getItem('preparations');
      const preps = data ? JSON.parse(data) : [];
      setPreparations(preps);
      calculateStats(preps);
    } catch (error) {
      console.error('Error loading preparations:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (preps: Preparation[]) => {
    const today = new Date().toDateString();
    const uploadedToday = preps.filter(
      (p) => new Date(p.uploadedAt).toDateString() === today
    ).length;
    const reviewed = preps.filter((p) => p.reviewed).length;
    const notReviewed = preps.filter((p) => !p.reviewed).length;

    setStats({
      uploadedToday,
      notUploaded: 6 - uploadedToday, // Assuming 6 servants
      reviewed,
      notReviewed,
    });
  };

  const handleReview = async (prepId: string) => {
    try {
      const updated = preparations.map((p) =>
        p.id === prepId
          ? {
              ...p,
              reviewed: true,
              reviewedAt: Date.now(),
              reviewedBy: 'father1', // Replace with actual father ID
            }
          : p
      );
      await AsyncStorage.setItem('preparations', JSON.stringify(updated));
      setPreparations(updated);
      calculateStats(updated);
    } catch (error) {
      console.error('Error updating preparation:', error);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#D4A574" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>لوحة متابعة الأب الكاهن</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <View style={[styles.statCard, { backgroundColor: '#3498db' }]}>
            <Text style={styles.statNumber}>{stats.uploadedToday}</Text>
            <Text style={styles.statLabel}>رفعوا اليوم</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#e74c3c' }]}>
            <Text style={styles.statNumber}>{stats.notUploaded}</Text>
            <Text style={styles.statLabel}>لم يرفعوا</Text>
          </View>
        </View>

        <View style={styles.statsContainer}>
          <View style={[styles.statCard, { backgroundColor: '#27ae60' }]}>
            <Text style={styles.statNumber}>{stats.reviewed}</Text>
            <Text style={styles.statLabel}>تمت مراجعتها</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#f39c12' }]}>
            <Text style={styles.statNumber}>{stats.notReviewed}</Text>
            <Text style={styles.statLabel}>بانتظار المراجعة</Text>
          </View>
        </View>

        {/* Preparations List */}
        <Text style={styles.sectionTitle}>التحضيرات</Text>
        {preparations.length === 0 ? (
          <Text style={styles.emptyText}>لا توجد تحضيرات</Text>
        ) : (
          <FlatList
            data={preparations}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            renderItem={({ item }) => (
              <View style={styles.preparationCard}>
                <View style={styles.cardHeader}>
                  <Text style={styles.servantName}>{item.servantName}</Text>
                  <Text style={styles.className}>{item.className}</Text>
                </View>

                <Text style={styles.notes} numberOfLines={2}>
                  {item.notes || 'بدون ملاحظات'}
                </Text>

                <Text style={styles.timestamp}>
                  {new Date(item.uploadedAt).toLocaleDateString('ar-EG')}
                </Text>

                {item.reviewed ? (
                  <View style={styles.reviewedBadge}>
                    <Text style={styles.reviewedText}>✓ تمت المراجعة</Text>
                  </View>
                ) : (
                  <TouchableOpacity
                    style={styles.reviewButton}
                    onPress={() => handleReview(item.id)}
                  >
                    <Text style={styles.reviewButtonText}>✓ تمت المراجعة</Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
          />
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    backgroundColor: '#D4A574',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  content: {
    flex: 1,
    padding: 15,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
  },
  statLabel: {
    fontSize: 12,
    color: '#fff',
    marginTop: 5,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
    textAlign: 'right',
  },
  emptyText: {
    textAlign: 'center',
    color: '#999',
    fontSize: 14,
  },
  preparationCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#D4A574',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  servantName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  className: {
    fontSize: 12,
    backgroundColor: '#D4A574',
    color: '#fff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  notes: {
    fontSize: 13,
    color: '#666',
    marginBottom: 8,
  },
  timestamp: {
    fontSize: 12,
    color: '#999',
    marginBottom: 10,
  },
  reviewButton: {
    backgroundColor: '#27ae60',
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
  },
  reviewButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  reviewedBadge: {
    backgroundColor: '#e8f5e9',
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#27ae60',
  },
  reviewedText: {
    color: '#27ae60',
    fontWeight: 'bold',
    fontSize: 14,
  },
});