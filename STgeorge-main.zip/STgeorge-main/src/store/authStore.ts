import { create } from 'zustand';
import { User, UserRole, AuthContextType } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AuthStore extends AuthContextType {
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  loading: true,

  setUser: (user) => set({ user }),
  setLoading: (loading) => set({ loading }),

  login: async (username: string, password: string, role: UserRole) => {
    set({ loading: true });
    try {
      // Simulate authentication - Replace with real Firebase auth
      const users = await AsyncStorage.getItem('users');
      const usersList = users ? JSON.parse(users) : getDefaultUsers();

      const user = usersList.find(
        (u: User) => u.username === username && u.password === password && u.role === role
      );

      if (!user) {
        throw new Error('بيانات الدخول غير صحيحة');
      }

      await AsyncStorage.setItem('currentUser', JSON.stringify(user));
      set({ user, loading: false });
    } catch (error) {
      set({ loading: false });
      throw error;
    }
  },

  logout: async () => {
    await AsyncStorage.removeItem('currentUser');
    set({ user: null });
  },
}));

function getDefaultUsers(): User[] {
  return [
    {
      id: 'admin1',
      username: 'admin',
      password: 'admin123',
      role: UserRole.ADMIN,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'father1',
      username: 'father1',
      password: 'father1',
      role: UserRole.FATHER,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'father2',
      username: 'father2',
      password: 'father2',
      role: UserRole.FATHER,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'father3',
      username: 'father3',
      password: 'father3',
      role: UserRole.FATHER,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'servant1',
      username: 'khadem1',
      password: 'khadem1',
      role: UserRole.SERVANT,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'servant2',
      username: 'khadem2',
      password: 'khadem2',
      role: UserRole.SERVANT,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'servant3',
      username: 'khadem3',
      password: 'khadem3',
      role: UserRole.SERVANT,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'servant4',
      username: 'khadem4',
      password: 'khadem4',
      role: UserRole.SERVANT,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'servant5',
      username: 'khadem5',
      password: 'khadem5',
      role: UserRole.SERVANT,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
    {
      id: 'servant6',
      username: 'khadem6',
      password: 'khadem6',
      role: UserRole.SERVANT,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    },
  ];
}

export const initializeUsers = async () => {
  const existingUsers = await AsyncStorage.getItem('users');
  if (!existingUsers) {
    await AsyncStorage.setItem('users', JSON.stringify(getDefaultUsers()));
  }
};